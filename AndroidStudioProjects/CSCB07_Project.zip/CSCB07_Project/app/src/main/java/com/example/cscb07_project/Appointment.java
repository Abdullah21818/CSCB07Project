package com.example.cscb07_project;

public class Appointment {
}
