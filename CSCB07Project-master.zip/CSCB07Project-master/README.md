# CSCB07Project

The director of a medical clinic needs help building an app for scheduling appointments with the 10 doctors who practice at the clinic. The idea is that patients would create user accounts and then be able to browse the doctors' schedules and select a time slot for their own appointment. Also, the doctors should be able to view which patients have scheduled appointments with them, and access basic information about each patient. 
