package com.example.CSCB07Project;

public interface Callback<DataType>{
    public void onCallback(DataType data);
}
